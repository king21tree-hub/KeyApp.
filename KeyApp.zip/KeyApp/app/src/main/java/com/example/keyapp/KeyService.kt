package com.example.keyapp

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

class KeyService : InputMethodService() {
    private enum class Mode { LETTERS, SYMBOLS, EMOJI, CLIP }

    private val ar = listOf("ضصثقفغعهخحجد", "شسيبلاتنمكط", "ئءؤرىةوزظذ")
    private val en = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val sym = listOf("1234567890", "@#$%&-+()/", "*\"':;!?،.؟")
    private val emojis = "😀😂🤣😊😍😘😎🤔😢😭😡👍👎🙏👏💪🔥❤️💔🎉✨🌹☕🌙⭐✅❌🤝🙌😴🤗😅🥰😇".let { s ->
        val out = mutableListOf<String>(); var i = 0
        while (i < s.length) { var n = s.offsetByCodePoints(i, 1)
            if (n < s.length && s[n] == '\uFE0F') n++
            out.add(s.substring(i, n)); i = n }
        out
    }
    private val dict = mapOf(
        true to "مرحبا مرحباً السلام عليكم شكراً شكرا كيف حالك الحمد لله إن شاء الله بسم الله صباح الخير مساء الخير أهلاً وسهلاً ممكن لو سمحت الآن اليوم غداً أين متى لماذا نعم لا تمام طيب جميل رائع أحبك الله يعطيك العافية".split(" "),
        false to "hello hi how are you thanks thank please good morning night today tomorrow where when why what yes no okay great love welcome sorry the and for with have this that".split(" "))

    private var arabic = true
    private var shift = false
    private var mode = Mode.LETTERS
    private var dark = true
    private var haptic = true
    private val clips = mutableListOf<String>()
    private lateinit var root: LinearLayout
    private lateinit var bar: LinearLayout
    private lateinit var body: LinearLayout
    private val h = Handler(Looper.getMainLooper())

    private val bg get() = if (dark) 0xFF1B1D22.toInt() else 0xFFE8EAEE.toInt()
    private val keyBg get() = if (dark) 0xFF2D3038.toInt() else Color.WHITE
    private val fnBg get() = if (dark) 0xFF3D4150.toInt() else 0xFFC9CDD6.toInt()
    private val fg get() = if (dark) Color.WHITE else 0xFF111111.toInt()
    private val accent = 0xFF3B82F6.toInt()

    override fun onCreate() {
        super.onCreate()
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank()) { clips.remove(t); clips.add(0, t); if (clips.size > 30) clips.removeLast() }
        }
    }

    override fun onCreateInputView(): View {
        loadPrefs()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6, 6, 6, 10) }
        bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(44)))
        root.addView(body, LinearLayout.LayoutParams(-1, -2))
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadPrefs(); mode = Mode.LETTERS; shift = false
        if (::root.isInitialized) render()
    }

    private fun loadPrefs() {
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        dark = p.getBoolean("dark", true); haptic = p.getBoolean("haptic", true)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun render() {
        root.setBackgroundColor(bg)
        body.removeAllViews()
        when (mode) {
            Mode.LETTERS -> { rows(if (arabic) ar else en); bottomRow() }
            Mode.SYMBOLS -> { rows(sym); bottomRow() }
            Mode.EMOJI -> grid(emojis) { commit(it) }
            Mode.CLIP -> if (clips.isEmpty()) body.addView(label("الحافظة فارغة — انسخ نصاً ليظهر هنا"))
                         else grid(clips) { commit(it) }
        }
        updateBar()
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(fg); gravity = Gravity.CENTER; setPadding(0, dp(40), 0, dp(40)) }

    private fun rows(r: List<String>) {
        r.forEachIndexed { i, s ->
            val row = newRow()
            if (i == 2 && mode == Mode.LETTERS) row.addView(key(if (shift) "⬆" else "⇧", 1.4f, fn = true, hl = shift) { shift = !shift; render() })
            s.forEach { c ->
                val ch = if (shift && !arabic) c.uppercaseChar().toString() else c.toString()
                row.addView(key(ch, 1f) { commit(ch); if (shift) { shift = false; render() } })
            }
            if (i == 2) row.addView(key("⌫", 1.4f, fn = true, repeat = true) { backspace() })
            body.addView(row)
        }
    }

    private fun bottomRow() {
        val row = newRow()
        row.addView(key(if (mode == Mode.SYMBOLS) (if (arabic) "أب" else "ABC") else "123", 1.5f, fn = true) {
            mode = if (mode == Mode.SYMBOLS) Mode.LETTERS else Mode.SYMBOLS; render() })
        row.addView(key("🌐", 1.2f, fn = true) { arabic = !arabic; mode = Mode.LETTERS; shift = false; render() })
        row.addView(key("😀", 1.2f, fn = true) { mode = Mode.EMOJI; render() })
        row.addView(key(if (arabic) "مسافة" else "space", 4f) { commit(" ") })
        row.addView(key(if (arabic) "،" else ".", 1f) { commit(if (arabic) "،" else ".") })
        row.addView(key("⏎", 1.5f, fn = true, hl = true) { enter() })
        body.addView(row)
    }

    private fun grid(items: List<String>, onTap: (String) -> Unit) {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val clipMode = mode == Mode.CLIP
        val per = if (clipMode) 1 else 8
        items.chunked(per).forEach { chunk ->
            val row = newRow(if (clipMode) 48 else 44)
            chunk.forEach { t ->
                row.addView(key(if (clipMode && t.length > 40) t.take(40) + "…" else t, 1f, size = if (clipMode) 14f else 22f) { onTap(t) })
            }
            col.addView(row)
        }
        sv.addView(col)
        body.addView(sv, LinearLayout.LayoutParams(-1, dp(176)))
        val row = newRow()
        row.addView(key(if (arabic) "أب" else "ABC", 1.5f, fn = true) { mode = Mode.LETTERS; render() })
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 5f))
        row.addView(key("⌫", 1.5f, fn = true, repeat = true) { backspace() })
        body.addView(row)
    }

    private fun updateBar() {
        bar.removeAllViews()
        fun tool(t: String, m: Mode) = key(t, 0.6f, fn = true, hl = mode == m) { mode = if (mode == m) Mode.LETTERS else m; render() }
        bar.addView(tool("📋", Mode.CLIP))
        bar.addView(key(if (dark) "☀" else "🌙", 0.6f, fn = true) {
            dark = !dark; getSharedPreferences("kb", MODE_PRIVATE).edit().putBoolean("dark", dark).apply(); render() })
        val words = suggestions()
        if (words.isEmpty()) bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 3f))
        words.forEach { w -> bar.addView(key(w, 1f, size = 16f) { replaceWord(w) }) }
    }

    private fun currentWord(): String {
        val t = currentInputConnection?.getTextBeforeCursor(30, 0)?.toString() ?: return ""
        return t.split(Regex("\\s")).lastOrNull() ?: ""
    }

    private fun suggestions(): List<String> {
        val w = currentWord(); if (w.isEmpty()) return emptyList()
        val isAr = w.first() in '\u0600'..'\u06FF'
        return dict[isAr].orEmpty().filter { it.startsWith(w, true) && !it.equals(w, true) }.take(3)
    }

    private fun replaceWord(s: String) {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(currentWord().length, 0); ic.commitText("$s ", 1); updateBar()
    }

    private fun commit(t: String) { currentInputConnection?.commitText(t, 1); updateBar() }
    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (TextUtilsEmpty(ic.getSelectedText(0))) ic.deleteSurroundingText(1, 0) else ic.commitText("", 1)
        updateBar()
    }
    private fun TextUtilsEmpty(c: CharSequence?) = c.isNullOrEmpty()
    private fun enter() {
        val a = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED &&
            (currentInputEditorInfo.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0)
            currentInputConnection?.performEditorAction(a) else commit("\n")
    }

    private fun newRow(height: Int = 48) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, dp(height))
    }

    private fun key(t: String, w: Float, fn: Boolean = false, hl: Boolean = false, repeat: Boolean = false,
                    size: Float = 18f, onTap: () -> Unit): TextView = TextView(this).apply {
        text = t; textSize = size; gravity = Gravity.CENTER; maxLines = 1
        setTextColor(if (hl) Color.WHITE else fg)
        background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(if (hl) accent else if (fn) fnBg else keyBg) }
        layoutParams = LinearLayout.LayoutParams(0, -1, w).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        val rep = object : Runnable { override fun run() { onTap(); h.postDelayed(this, 55) } }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { v.alpha = 0.6f
                    if (haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (repeat) { onTap(); h.postDelayed(rep, 400) } }
                MotionEvent.ACTION_UP -> { v.alpha = 1f; h.removeCallbacks(rep); if (!repeat) onTap() }
                MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; h.removeCallbacks(rep) }
            }
            true
        }
    }
}
