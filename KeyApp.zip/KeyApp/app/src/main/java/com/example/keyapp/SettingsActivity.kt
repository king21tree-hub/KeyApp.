package com.example.keyapp

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { root.addView(it) }
        root.addView(TextView(this).apply { text = "كيبورد برو"; textSize = 28f; gravity = Gravity.CENTER })
        btn("1) تفعيل الكيبورد") { startActivity(android.content.Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        btn("2) اختيار الكيبورد") { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        val theme = Switch(this).apply { text = "الوضع الداكن"; isChecked = p.getBoolean("dark", true)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean("dark", v).apply() } }
        val haptic = Switch(this).apply { text = "اهتزاز عند الضغط"; isChecked = p.getBoolean("haptic", true)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean("haptic", v).apply() } }
        root.addView(theme); root.addView(haptic)
        root.addView(EditText(this).apply { hint = "جرّب الكيبورد هنا" })
        setContentView(root)
    }
}
